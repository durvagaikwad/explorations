
import React from 'react';
import { motion } from 'motion/react';

interface DocumentPreviewViewProps {
  stampUrl: string;
}

const DocumentPreviewView: React.FC<DocumentPreviewViewProps> = ({ stampUrl }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative w-full max-w-2xl aspect-[1.4/1] bg-[#fdfdf7] rounded-sm shadow-xl overflow-hidden border border-stone-200 p-6 sm:p-12 flex flex-col items-center justify-center"
      style={{
        boxShadow: '0 20px 40px -10px rgba(0, 0, 0, 0.2), inset 0 0 80px rgba(139, 115, 85, 0.05)'
      }}
    >
      {/* Paper Texture */}
      <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')]" />

      <div className="flex w-full gap-4 sm:gap-8 relative z-10">
        {/* Mock Content */}
        <div className="flex-1 space-y-4 sm:space-y-6">
          <div className="space-y-3 sm:space-y-4 opacity-20">
            <div className="h-3 sm:h-4 bg-stone-300 w-1/4 rounded-full" />
            <div className="space-y-1.5 sm:space-y-2">
              <div className="h-1.5 sm:h-2 bg-stone-200 w-full rounded-full" />
              <div className="h-1.5 sm:h-2 bg-stone-200 w-full rounded-full" />
              <div className="h-1.5 sm:h-2 bg-stone-200 w-3/4 rounded-full" />
            </div>
          </div>
          
          <div className="pt-4 sm:pt-8 space-y-3 sm:space-y-4 opacity-10">
            <div className="h-1.5 sm:h-2 bg-stone-200 w-full rounded-full" />
            <div className="h-1.5 sm:h-2 bg-stone-200 w-4/5 rounded-full" />
            <div className="h-1.5 sm:h-2 bg-stone-200 w-full rounded-full" />
          </div>
        </div>

        {/* Stamp Area */}
        <div className="w-1/3 flex flex-col items-end">
          <div className="relative group">
            {/* Subtle glow/shadow for the stamp */}
            <div className="absolute -inset-2 bg-black/5 blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
            <motion.img 
              initial={{ rotate: 10, y: 10, opacity: 0 }}
              animate={{ rotate: 3, y: 0, opacity: 1 }}
              transition={{ delay: 0.2, type: 'spring', stiffness: 100 }}
              src={stampUrl} 
              alt="Stamp on Document" 
              className="w-24 sm:w-40 h-auto drop-shadow-md cursor-grab active:cursor-grabbing hover:scale-105 transition-transform"
            />
          </div>
        </div>
      </div>

      {/* Postmark Style Overlays */}
      <div className="absolute top-1/4 right-1/4 opacity-5 rotate-12 pointer-events-none scale-75 sm:scale-100">
        <div className="w-24 sm:w-32 h-24 sm:h-32 rounded-full border-[6px] sm:border-[8px] border-stone-900 flex items-center justify-center">
          <div className="w-16 sm:w-24 h-16 sm:h-24 rounded-full border-2 sm:border-4 border-stone-900 border-dashed" />
        </div>
      </div>
    </motion.div>
  );
};

export default DocumentPreviewView;
