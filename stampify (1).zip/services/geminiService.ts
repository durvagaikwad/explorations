
import { GoogleGenAI } from "@google/genai";
import { StampStyle } from "../types";

const STYLE_INSTRUCTIONS: Record<StampStyle, string> = {
  classic: `STYLE: Classic Official. 
    - Aesthetics: Formal heraldic borders, deep royal colors (navy, maroon, or forest green).
    - Typography: Traditional bold Roman serif.
    - Artistic Technique: Detailed oil painting or official portrait style.
    - Features: Ornate corner ornaments and a thick double-line frame.`,
    
  vintage: `STYLE: Engraved Vintage. 
    - Aesthetics: Monochromatic or sepia duotone, heavy aged paper texture.
    - Typography: Antique decorative slab-serif.
    - Artistic Technique: Intaglio engraving with visible cross-hatching and fine line-work.
    - Features: Faded edges and subtle ink bleeds as if printed on an old press.`,
    
  minimal: `STYLE: Modern Minimal. 
    - Aesthetics: Clean, flat design with a single vibrant accent color.
    - Typography: Modern geometric sans-serif (like Helvetica or Futura).
    - Artistic Technique: Vector illustration with solid shapes and no gradients.
    - Features: Ultra-thin borders and maximum white space.`,
    
  event: `STYLE: Commemorative Event. 
    - Aesthetics: Festive and celebratory, including decorative banners or laurel wreaths.
    - Typography: Elegant script or high-contrast modern serif.
    - Artistic Technique: Vibrant gouache or poster-art style.
    - Features: Includes a "100 YEARS" or "ANNIVERSARY" motif subtly in the border.`,
    
  travel: `STYLE: Travel Landmark. 
    - Aesthetics: Scenic and vibrant, evoking mid-century travel posters.
    - Typography: Playful Art Deco or condensed block fonts.
    - Artistic Technique: High-saturation color lithograph.
    - Features: Includes "AIR MAIL" or "PAR AVION" markings and a distinct destination feel.`
};

export async function generateStamp(
  base64Image: string, 
  mimeType: string, 
  countryName: string,
  style: StampStyle,
  denomination: string
): Promise<string> {
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || process.env.API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
  
  const displayCountry = countryName.trim() || "INTERNATIONAL POST";
  const displayDenom = denomination.trim() || "$1.20";
  const stylePrompt = STYLE_INSTRUCTIONS[style];

  const prompt = `Convert this image into a premium postal stamp using the following specific artistic direction:

  ${stylePrompt}

  CRITICAL TECHNICAL REQUIREMENT:
  1. BACKGROUND: Use a SOLID, PURE BLACK (#000000) flat color for the area OUTSIDE the stamp borders. 
  2. NO OVERLAP: The pure black background must be a clean "frame" around the stamp. Do not allow any part of the stamp design to bleed into the black background.
  3. NO EFFECTS: Do not add any shadows, glows, or lighting gradients to the black background area.

  UNIVERSAL STAMP REQUIREMENTS:
  1. PERFORATIONS: Clean, sharp, highly detailed white serrated edges (the classic stamp "teeth").
  2. DETAILS: An elegant denomination (e.g., "${displayDenom}") and the text "${displayCountry.toUpperCase()}" beautifully integrated into the design.
  3. POSTMARK: Add one very subtle, faint circular postmark overlapping the top corner of the stamp.

  Ensure the area outside the white serrated edges is PURE, UNIFORM BLACK. The subject of the stamp should be the provided image, transformed into the specified style.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image.split(',')[1],
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const mType = part.inlineData.mimeType || 'image/png';
        return `data:${mType};base64,${part.inlineData.data}`;
      }
    }

    throw new Error("The AI did not return an image. Please try a different photo.");
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
