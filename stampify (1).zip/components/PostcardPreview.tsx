
import React from 'react';
import { motion } from 'motion/react';

interface PostcardPreviewProps {
  stampUrl: string;
  onClose: () => void;
}

const PostcardPreview: React.FC<PostcardPreviewProps> = ({ stampUrl, onClose }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-stone-900/40 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        layoutId="postcard"
        className="relative w-full max-w-2xl aspect-[1.6/1] bg-[#f5f5f0] rounded-sm shadow-2xl overflow-hidden border-[1px] border-stone-200 p-8 flex flex-col cursor-default"
        onClick={(e) => e.stopPropagation()}
        style={{
          boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5), inset 0 0 100px rgba(139, 115, 85, 0.1)'
        }}
      >
        {/* Postcard Texture Overlay */}
        <div className="absolute inset-0 opacity-10 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')]" />

        {/* Content */}
        <div className="flex-1 flex gap-8">
          {/* Left Side: Message Area */}
          <div className="flex-1 flex flex-col">
            <div className="mb-4">
              <h2 className="font-serif italic text-stone-400 text-sm tracking-widest uppercase">Postcard</h2>
            </div>
            <div className="flex-1 flex flex-col justify-center space-y-4 opacity-40">
                <div className="h-[2px] bg-stone-300 w-full" />
                <div className="h-[2px] bg-stone-300 w-[90%]" />
                <div className="h-[2px] bg-stone-300 w-[95%]" />
                <div className="h-[2px] bg-stone-300 w-[85%]" />
                <div className="h-[2px] bg-stone-300 w-[60%]" />
            </div>
          </div>

          {/* Vertical Divider */}
          <div className="w-[1px] bg-stone-300 h-full relative">
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#f5f5f0] py-2">
                <div className="w-1.5 h-1.5 rounded-full border border-stone-300" />
             </div>
          </div>

          {/* Right Side: Stamp & Address */}
          <div className="flex-1 flex flex-col">
            {/* Stamp Position */}
            <div className="flex justify-end mb-12">
               <div className="relative group">
                  <div className="absolute -inset-1 bg-stone-200/50 blur-sm opacity-0 group-hover:opacity-100 transition-opacity" />
                  <img 
                    src={stampUrl} 
                    alt="Stamp on Postcard" 
                    className="w-24 sm:w-32 h-auto drop-shadow-md rotate-3 group-hover:rotate-0 transition-transform duration-500"
                  />
               </div>
            </div>

            {/* Address Lines */}
            <div className="flex-1 flex flex-col justify-end space-y-8 pb-4">
              <div className="border-b-[2px] border-stone-300 w-full h-0" />
              <div className="border-b-[2px] border-stone-300 w-full h-0" />
              <div className="border-b-[2px] border-stone-300 w-full h-0" />
            </div>
          </div>
        </div>

        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-stone-900/5 hover:bg-stone-900/10 flex items-center justify-center transition-colors group"
        >
          <i className="fas fa-times text-stone-400 group-hover:text-stone-900 transition-colors"></i>
        </button>

        {/* Air Mail Label */}
        <div className="absolute bottom-6 left-8 flex items-center gap-2">
           <div className="px-2 py-0.5 border-2 border-blue-600/30 text-[10px] font-black text-blue-600/40 uppercase tracking-tighter transform -rotate-2">
             Air Mail
           </div>
           <div className="px-2 py-0.5 border-2 border-red-600/30 text-[10px] font-black text-red-600/40 uppercase tracking-tighter transform rotate-1">
             First Class
           </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default PostcardPreview;
