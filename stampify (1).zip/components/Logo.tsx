
import React from 'react';

const Logo: React.FC<{ size?: number }> = ({ size = 44 }) => {
  return (
    <div 
      className="relative flex items-center justify-center border border-dashed border-stone-300 rounded-md"
      style={{ width: size, height: size }}
    >
      <div 
        className="w-[65%] h-[65%] bg-[#a32a1d] relative flex items-center justify-center"
        style={{
          boxShadow: '0 0 0 2px #a32a1d',
          filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))',
          // More precise stamp serration
          clipPath: 'polygon(0% 10%, 5% 5%, 10% 0%, 15% 5%, 20% 0%, 25% 5%, 30% 0%, 35% 5%, 40% 0%, 45% 5%, 50% 0%, 55% 5%, 60% 0%, 65% 5%, 70% 0%, 75% 5%, 80% 0%, 85% 5%, 90% 0%, 95% 5%, 100% 10%, 95% 15%, 100% 20%, 95% 25%, 100% 30%, 95% 35%, 100% 40%, 95% 45%, 100% 50%, 95% 55%, 100% 60%, 95% 65%, 100% 70%, 95% 75%, 100% 80%, 95% 85%, 100% 90%, 95% 95%, 90% 100%, 85% 95%, 80% 100%, 75% 95%, 70% 100%, 65% 95%, 60% 100%, 55% 95%, 50% 100%, 45% 95%, 40% 100%, 35% 95%, 30% 100%, 25% 95%, 20% 100%, 15% 95%, 10% 100%, 5% 95%, 0% 90%, 5% 85%, 0% 80%, 5% 75%, 0% 70%, 5% 65%, 0% 60%, 5% 55%, 0% 50%, 5% 45%, 0% 40%, 5% 35%, 0% 30%, 5% 25%, 0% 20%, 5% 15%)'
        }}
      >
        <div className="w-[60%] h-[60%] bg-white flex items-center justify-center rounded-[1px]">
          <div className="w-1.5 h-1.5 bg-[#a32a1d] rounded-full" />
        </div>
      </div>
    </div>
  );
};

export default Logo;
