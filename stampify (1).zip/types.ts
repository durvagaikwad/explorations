
export type StampStyle = 'classic' | 'vintage' | 'minimal' | 'event' | 'travel';

export interface StampResult {
  id: string;
  imageUrl: string;
  originalName: string;
  style: StampStyle;
  country: string;
  denomination: string;
  timestamp: number;
}

export interface AppState {
  isProcessing: boolean;
  activeResult: StampResult | null;
  error: string | null;
  history: StampResult[];
}
