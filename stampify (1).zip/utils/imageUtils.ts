
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
};

/**
 * Removes the background of an image using a flood-fill algorithm.
 * This ensures only the outer background area is made transparent,
 * leaving pixels inside the stamp (even if they match the background color) untouched.
 */
export const removeImageBackground = (dataUrl: string): Promise<string> => {
  return new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return resolve(dataUrl);

      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const { data, width, height } = imageData;

      // Sample the background color from the top-left corner
      const r_bg = data[0];
      const g_bg = data[1];
      const b_bg = data[2];

      const threshold = 40;
      const visited = new Uint8Array(width * height);
      const queue: number[] = [];

      // Add the four corners as seeds for the flood fill
      const seeds = [
        [0, 0],
        [width - 1, 0],
        [0, height - 1],
        [width - 1, height - 1]
      ];

      for (const [sx, sy] of seeds) {
        const idx = sy * width + sx;
        if (!visited[idx]) {
          queue.push(sx, sy);
          visited[idx] = 1;
        }
      }

      // Non-recursive flood fill
      let head = 0;
      while (head < queue.length) {
        const x = queue[head++];
        const y = queue[head++];

        const idx = (y * width + x) * 4;
        const r = data[idx];
        const g = data[idx + 1];
        const b = data[idx + 2];

        const diff = Math.abs(r - r_bg) + Math.abs(g - g_bg) + Math.abs(b - b_bg);

        if (diff < threshold) {
          // It's background: make it transparent
          data[idx + 3] = 0;

          // Check neighbors
          const neighbors = [
            [x + 1, y], [x - 1, y], [x, y + 1], [x, y - 1]
          ];

          for (const [nx, ny] of neighbors) {
            if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
              const nIdx = ny * width + nx;
              if (!visited[nIdx]) {
                visited[nIdx] = 1;
                queue.push(nx, ny);
              }
            }
          }
        }
      }

      ctx.putImageData(imageData, 0, 0);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
};

export const downloadImage = (url: string, filename: string) => {
  const link = document.createElement('a');
  link.href = url;
  link.download = `stampify-${filename.split('.')[0]}.png`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const downloadSVG = (url: string, filename: string) => {
  const img = new Image();
  img.onload = () => {
    const width = img.width;
    const height = img.height;
    const svgString = `
<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
  <image href="${url}" width="${width}" height="${height}" />
</svg>`.trim();
    
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const svgUrl = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = svgUrl;
    link.download = `stampify-${filename.split('.')[0]}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(svgUrl);
  };
  img.src = url;
};
