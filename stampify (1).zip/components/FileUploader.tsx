
import React, { useRef } from 'react';
import { Camera, Upload } from 'lucide-react';

interface FileUploaderProps {
  onUpload: (file: File) => void;
  isProcessing: boolean;
  small?: boolean;
}

const FileUploader: React.FC<FileUploaderProps> = ({ onUpload, isProcessing, small }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  const handleContainerClick = () => {
    if (!isProcessing) {
      fileInputRef.current?.click();
    }
  };

  return (
    <div 
      onClick={handleContainerClick}
      className={`
        relative group cursor-pointer
        w-full ${small ? 'h-24' : 'aspect-[4/3]'}
        bg-[#f0ede6]/50 rounded-[2.5rem]
        flex flex-col items-center justify-center p-8
        transition-all duration-300
        ${isProcessing ? 'opacity-50 pointer-events-none' : ''}
      `}
    >
      {/* Dashed Border Overlay */}
      <div className="absolute inset-4 border border-dashed border-stone-300/60 rounded-[1.8rem] pointer-events-none group-hover:border-stone-400 group-hover:inset-3 transition-all duration-300" />
      
      <input 
         type="file" 
         ref={fileInputRef}
         onChange={handleFileChange}
         accept="image/*"
         className="hidden"
      />
      
      <div className="text-center relative z-10 flex flex-col items-center">
        <div className={`mb-6 p-4 rounded-2xl bg-stone-200/50 group-hover:bg-stone-200 transition-colors`}>
          <Upload className="w-8 h-8 text-stone-500 group-hover:text-stone-800" />
        </div>
        
        <h2 className="text-xl sm:text-2xl font-official font-bold text-stone-900 mb-2">
          Upload your image
        </h2>
        
        <div className="w-24 h-[1px] bg-stone-300/50 mb-3" />
        
        <p className="text-stone-400 text-[9px] font-bold uppercase tracking-[0.2em] mb-4">
          Click to browse or drag & drop
        </p>

        <p className="text-stone-300 text-[8px] font-bold uppercase tracking-widest mt-8">
          PNG, JPG, WEBP SUPPORTED
        </p>
      </div>
    </div>
  );
};

export default FileUploader;
