
import React, { useState } from 'react';
import DocumentPreviewView from './DocumentPreviewView';
import { AnimatePresence, motion } from 'motion/react';
import { Plus, Maximize2, FileText } from 'lucide-react';

interface StampDisplayProps {
  imageUrl: string;
  originalName: string;
  onReset: () => void;
  minimal?: boolean;
}

const StampDisplay: React.FC<StampDisplayProps> = ({ imageUrl, originalName, onReset, minimal }) => {
  const [previewMode, setPreviewMode] = useState<'flat' | 'document'>('flat');

  return (
    <div className="flex flex-col items-center w-full lg:h-full justify-center lg:overflow-hidden relative py-4 lg:py-0">
      {/* Toggle - Responsive Placement */}
      <div className="absolute top-2 sm:top-0 right-2 sm:right-0 p-2 sm:p-4 z-30">
        <div className="flex bg-stone-100 p-1 rounded-lg border border-stone-200 shadow-sm scale-90 sm:scale-100 origin-top-right">
          <button
            onClick={() => setPreviewMode('flat')}
            className={`px-3 sm:px-4 py-1 sm:py-1.5 text-[9px] sm:text-[10px] font-black uppercase tracking-widest rounded-md transition-all flex items-center gap-2 ${
              previewMode === 'flat' 
                ? 'bg-stone-900 text-white shadow-md' 
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Maximize2 size={10} /> Flat
          </button>
          <button
            onClick={() => setPreviewMode('document')}
            className={`px-3 sm:px-4 py-1 sm:py-1.5 text-[9px] sm:text-[10px] font-black uppercase tracking-widest rounded-md transition-all flex items-center gap-2 ${
              previewMode === 'document' 
                ? 'bg-stone-900 text-white shadow-md' 
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <FileText size={10} /> Context
          </button>
        </div>
      </div>

      <div className="relative mb-4 sm:mb-6 flex-1 w-full flex justify-center items-center min-h-0">
        <AnimatePresence mode="wait">
          {previewMode === 'flat' ? (
            <motion.div
              key="flat"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="relative p-4 sm:p-8 rounded-2xl overflow-hidden shadow-2xl bg-white border-[4px] sm:border-[6px] border-white flex items-center justify-center max-h-full"
              style={{
                backgroundImage: `linear-gradient(45deg, #f9f9f9 25%, transparent 25%), 
                                  linear-gradient(-45deg, #f9f9f9 25%, transparent 25%), 
                                  linear-gradient(45deg, transparent 75%, #f9f9f9 75%), 
                                  linear-gradient(-45deg, transparent 75%, #f9f9f9 75%)`,
                backgroundSize: '12px 12px',
                backgroundPosition: '0 0, 0 6px, 6px -6px, -6px 0px'
              }}
            >
              <img 
                src={imageUrl} 
                alt="Generated Stamp" 
                className="relative max-w-full max-h-full object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.1)] sm:drop-shadow-[0_15px_30px_rgba(0,0,0,0.1)]"
              />
            </motion.div>
          ) : (
            <div key="document" className="w-full flex justify-center h-full items-center p-2 sm:p-0 overflow-hidden">
              <DocumentPreviewView stampUrl={imageUrl} />
            </div>
          )}
        </AnimatePresence>
      </div>

      {!minimal && (
        <div className="flex items-center gap-3 w-full max-w-xs sm:max-w-sm shrink-0 pb-2 sm:pb-4">
          <button
            onClick={onReset}
            className="flex-1 bg-white border-2 border-stone-100 text-stone-400 py-3 sm:py-3.5 rounded-xl hover:border-stone-900 hover:text-stone-900 transition-all flex items-center justify-center gap-2 sm:gap-3 active:scale-95 group"
          >
            <Plus size={14} />
            <span className="text-[10px] sm:text-xs uppercase tracking-[0.1em] sm:tracking-[0.2em]">New Stamp</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default StampDisplay;
