
import React, { useState, useCallback } from 'react';
import FileUploader from './components/FileUploader';
import LoadingScreen from './components/LoadingScreen';
import StampDisplay from './components/StampDisplay';
import Logo from './components/Logo';
import { fileToBase64, removeImageBackground } from './utils/imageUtils';
import { generateStamp } from './services/geminiService';
import { StampResult, StampStyle } from './types';
import { 
  Stamp, 
  ChevronLeft, 
  Palette, 
  Wand2 as MagicWand, 
  Trash2, 
  Globe, 
  Layout, 
  ShieldCheck, 
  CircleDot, 
  Award, 
  Plane,
  Grid,
  FileImage,
  Code
} from 'lucide-react';
import { downloadImage, downloadSVG } from './utils/imageUtils';

const STYLES: { id: StampStyle; label: string; icon: React.ReactNode; desc: string }[] = [
  { id: 'vintage', label: 'Vintage', icon: <Stamp size={16} />, desc: 'Engraved' },
  { id: 'classic', label: 'Classic', icon: <ShieldCheck size={16} />, desc: 'Formal' },
  { id: 'minimal', label: 'Minimal', icon: <CircleDot size={16} />, desc: 'Clean' },
  { id: 'event', label: 'Event', icon: <Award size={16} />, desc: 'Festive' },
  { id: 'travel', label: 'Travel', icon: <Plane size={16} />, desc: 'Scenic' },
];

const App: React.FC = () => {
  const [view, setView] = useState<'setup' | 'workspace'>('setup');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeResult, setActiveResult] = useState<StampResult | null>(null);
  const [history, setHistory] = useState<StampResult[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [country, setCountry] = useState('');
  const [denomination, setDenomination] = useState('');
  const [selectedStyle, setSelectedStyle] = useState<StampStyle>('vintage');
  const [sourceData, setSourceData] = useState<{ base64: string; type: string; name: string } | null>(null);

  const processImage = useCallback(async (base64: string, type: string, name: string, style: StampStyle, origin: string, denom: string) => {
    setError(null);
    setIsProcessing(true);

    try {
      const rawStampUrl = await generateStamp(base64, type, origin, style, denom);
      const transparentStampUrl = await removeImageBackground(rawStampUrl);
      
      const newStamp: StampResult = {
        id: crypto.randomUUID(),
        imageUrl: transparentStampUrl,
        originalName: name,
        style,
        country: origin,
        denomination: denom,
        timestamp: Date.now()
      };

      setHistory(prev => [newStamp, ...prev]);
      setActiveResult(newStamp);
      setView('workspace');
    } catch (err: any) {
      setError(err.message || 'Transformation failed. Try a different image.');
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const handleFileUpload = async (file: File) => {
    try {
      const base64 = await fileToBase64(file);
      const data = { base64, type: file.type, name: file.name };
      setSourceData(data);
    } catch (err) {
      setError("Failed to read image file.");
    }
  };

  const handleGenerate = () => {
    if (sourceData) {
      processImage(sourceData.base64, sourceData.type, sourceData.name, selectedStyle, country, denomination);
    }
  };

  const handleStyleChange = (style: StampStyle) => {
    setSelectedStyle(style);
    if (sourceData && !isProcessing) {
      processImage(sourceData.base64, sourceData.type, sourceData.name, style, country, denomination);
    }
  };

  const handleReEngrave = () => {
    if (sourceData && !isProcessing) {
      processImage(sourceData.base64, sourceData.type, sourceData.name, selectedStyle, country, denomination);
    }
  };

  const handleGoBack = () => {
    setView('setup');
  };

  const selectFromHistory = (stamp: StampResult) => {
    setActiveResult(stamp);
    setSelectedStyle(stamp.style);
    setCountry(stamp.country);
    setDenomination(stamp.denomination);
  };

  // Step 1: Setup View
  if (view === 'setup') {
    return (
      <div className="min-h-screen md:h-screen w-full flex flex-col bg-[#f5f2eb] md:overflow-hidden relative pb-20 md:pb-0">
        {/* Top Navigation */}
        <header className="h-20 sm:h-24 px-4 sm:px-12 flex items-center justify-between border-b border-stone-200/50 shrink-0 bg-white/40 backdrop-blur-md">
          <div className="flex items-center gap-3 sm:gap-6">
            <Logo size={36} />
            <div className="flex flex-col justify-center">
              <h1 className="text-2xl sm:text-3xl font-official font-[900] text-stone-900 tracking-[0.2em] uppercase leading-[0.8]">
                Stampify
              </h1>
              <p className="text-[9px] sm:text-[10px] text-stone-500 font-bold uppercase tracking-[0.1em] mt-1.5 opacity-60">
                The Philatelic Engine
              </p>
            </div>
          </div>

          {/* Stepper */}
          <nav className="hidden md:flex items-center gap-12">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-stone-900 text-white flex items-center justify-center text-[12px] font-bold">1</div>
              <span className="text-[12px] font-black uppercase tracking-widest text-stone-900">Upload</span>
            </div>
            <div className="w-16 h-[1px] bg-stone-300" />
            <div className="flex items-center gap-3 opacity-30">
              <div className="w-9 h-9 rounded-full border border-stone-300 text-stone-400 flex items-center justify-center text-[12px] font-bold">2</div>
              <span className="text-[12px] font-black uppercase tracking-widest text-stone-400">Style & Export</span>
            </div>
          </nav>
        </header>


        {/* Main Area */}
        <main className="flex-1 flex flex-col md:flex-row items-center justify-center px-4 sm:px-12 max-w-7xl mx-auto w-full gap-8 md:gap-12 lg:gap-24 overflow-y-auto pt-6 pb-36 md:py-0">
          <div className="w-full md:w-1/2 space-y-5 md:space-y-8 animate-in slide-in-from-left duration-700">
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-[#cc5a4a] uppercase tracking-[0.3em]">Step One</p>
              <h2 className="text-3xl sm:text-[40px] md:text-[56px] font-official font-black text-stone-900 leading-[1.1]">
                Drop in a <br/>picture.
              </h2>
            </div>
            <p className="text-base sm:text-lg md:text-xl font-official italic text-stone-500 max-w-md leading-relaxed">
              Turn your images into collectible-style postal stamps
            </p>

            <div className="pt-2 space-y-4">
              <div className="flex items-center gap-4 text-stone-400">
                <Globe size={18} className="shrink-0" />
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="Issuing Origin (e.g. United Kingdom)"
                  className="bg-transparent border-b border-stone-300 py-3 w-full focus:border-stone-900 outline-none text-base text-stone-700 placeholder:text-stone-300 font-medium transition-all"
                />
              </div>
              <div className="flex items-center gap-4 text-stone-400">
                <div className="w-4 h-4 flex items-center justify-center font-bold text-base">$</div>
                <input
                  type="text"
                  value={denomination}
                  onChange={(e) => setDenomination(e.target.value)}
                  placeholder="Denomination (e.g. $1.20 or 80c)"
                  className="bg-transparent border-b border-stone-300 py-3 w-full focus:border-stone-900 outline-none text-base text-stone-700 placeholder:text-stone-300 font-medium transition-all"
                />
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 max-w-lg animate-in slide-in-from-right duration-700">
            {sourceData ? (
              <div className="relative group aspect-[4/3] w-full rounded-[2.5rem] overflow-hidden border-2 border-white shadow-2xl bg-white p-4">
                <div className="w-full h-full rounded-[1.8rem] overflow-hidden relative">
                  <img 
                    src={sourceData.base64} 
                    alt="Preview" 
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-stone-900/40 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                      onClick={() => setSourceData(null)}
                      className="px-6 py-3.5 rounded-full bg-white text-stone-900 font-bold uppercase tracking-widest text-[10px] hover:bg-stone-100 transition-all shadow-xl active:scale-95"
                    >
                      Choose Different
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <FileUploader onUpload={handleFileUpload} isProcessing={isProcessing} />
            )}
            
            {error && (
              <div className="mt-6 p-4 bg-red-50 border-l-4 border-red-500 text-red-700 flex items-center gap-3 rounded-r-xl text-[10px] font-bold uppercase tracking-wider animate-pulse transition-all">
                {error}
              </div>
            )}
          </div>
        </main>

        {/* Bottom Bar */}
        <footer className="h-20 px-6 sm:px-12 border-t border-stone-200/50 flex items-center justify-end bg-white/70 backdrop-blur-md shrink-0 fixed bottom-0 left-0 right-0 z-30">
           <button
            onClick={handleGenerate}
            disabled={isProcessing || !sourceData}
            className={`flex items-center gap-4 px-8 sm:px-10 py-3.5 sm:py-4 text-white rounded-lg font-black uppercase tracking-[0.2em] text-[10px] shadow-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed group active:scale-95 ${sourceData ? 'bg-stone-900 hover:bg-stone-800' : 'bg-[#b5b0a3]'}`}
           >
             Engrave
             <ChevronLeft size={14} className="rotate-180 group-hover:translate-x-1 transition-transform text-white shrink-0" />
           </button>
        </footer>

        {isProcessing && (
          <div className="fixed inset-0 bg-[#f5f2eb]/90 backdrop-blur-sm z-50 flex items-center justify-center p-8">
            <LoadingScreen />
          </div>
        )}
      </div>
    );
  }


  // Step 2 & 3: Workspace View
  return (
    <div className="min-h-screen lg:h-screen w-full flex flex-col bg-[#f5f2eb] lg:overflow-hidden relative pb-16 lg:pb-0">
      {/* Top Navigation */}
      <header className="h-20 sm:h-24 px-4 sm:px-12 flex items-center justify-between border-b border-stone-200/50 shrink-0 bg-white/50 backdrop-blur">
        <div className="flex items-center gap-3 sm:gap-6 cursor-pointer" onClick={handleGoBack}>
          <Logo size={36} />
          <div>
            <h1 className="text-2xl sm:text-3xl font-official font-[900] text-stone-900 tracking-[0.2em] uppercase leading-none">
              Stampify
            </h1>
          </div>
        </div>

        {/* Stepper */}
        <nav className="hidden md:flex items-center gap-8 ml-auto mr-8">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={handleGoBack}>
            <div className="w-8 h-8 rounded-full border-2 border-stone-900 text-stone-900 flex items-center justify-center text-[11px] font-bold group-hover:bg-stone-900 group-hover:text-white transition-all">1</div>
            <span className="text-[11px] font-black uppercase tracking-widest text-stone-900">Upload</span>
          </div>
          <div className="w-12 h-[1px] bg-stone-900" />
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-bold ${view === 'workspace' ? 'bg-stone-900 text-white' : 'border-2 border-stone-300 text-stone-400'}`}>2</div>
            <span className={`text-[11px] font-black uppercase tracking-widest ${view === 'workspace' ? 'text-stone-900' : 'text-stone-400'}`}>Style & Export</span>
          </div>
        </nav>
      </header>

      {/* Workspace Area */}
      <main className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-y-auto lg:overflow-hidden pb-56 lg:pb-0">
        
        {/* Style Sidebar */}
        <aside className="w-full lg:w-80 border-b lg:border-b-0 lg:border-r border-stone-200/50 bg-white/30 flex flex-col shrink-0 order-2 lg:order-1">
          <div className="px-4 sm:px-6 py-5 space-y-6 flex-1 lg:overflow-y-auto overflow-x-hidden text-stone-300">
            <div className="space-y-4">
              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 flex items-center gap-2">
                <Palette size={12} /> Select Style
              </label>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-1 gap-2.5">
                {STYLES.map((style) => (
                  <button
                    key={style.id}
                    disabled={isProcessing}
                    onClick={() => handleStyleChange(style.id)}
                    className={`
                      relative p-3 rounded-xl border flex items-center gap-3.5 transition-all text-left w-full
                      ${selectedStyle === style.id 
                        ? 'border-stone-900 bg-stone-900 text-white shadow-xl -translate-y-0.5' 
                        : 'border-stone-200 bg-white text-stone-500 hover:border-stone-400 hover:shadow-md'}
                      ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer active:scale-95'}
                    `}
                  >
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${selectedStyle === style.id ? 'bg-white/10' : 'bg-stone-50'}`}>
                      <span className={selectedStyle === style.id ? 'text-white' : 'text-stone-400'}>
                        {style.icon}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-[11px] font-black uppercase tracking-widest leading-none mb-1 truncate">{style.label}</div>
                      <div className={`text-[9px] font-medium ${selectedStyle === style.id ? 'text-stone-400' : 'text-stone-300'} truncate uppercase tracking-wider`}>{style.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-stone-200/50 space-y-5">
               <div className="space-y-4">
                  <div className="space-y-1.5">
                    <p className="text-[10px] text-stone-400 font-bold uppercase tracking-[0.3em]">Issuing Origin</p>
                    <input
                      type="text"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      placeholder="Origin"
                      className="w-full bg-stone-900/5 border border-stone-200 rounded-xl px-4 py-3 text-base font-official font-bold text-stone-800 focus:bg-white focus:border-stone-900 transition-all outline-none"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <p className="text-[10px] text-stone-400 font-bold uppercase tracking-[0.3em]">Denomination</p>
                    <input
                      type="text"
                      value={denomination}
                      onChange={(e) => setDenomination(e.target.value)}
                      placeholder="e.g. $1.20"
                      className="w-full bg-stone-900/5 border border-stone-200 rounded-xl px-4 py-3 text-base font-official font-bold text-stone-800 focus:bg-white focus:border-stone-900 transition-all outline-none"
                    />
                  </div>

                  <button
                    onClick={handleReEngrave}
                    disabled={isProcessing}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-stone-200 text-stone-600 rounded-xl text-[10px] uppercase font-black tracking-widest hover:bg-stone-300 transition-all disabled:opacity-50 active:scale-95"
                  >
                    <MagicWand size={14} className={isProcessing ? 'animate-spin' : ''} />
                    Apply Changes
                  </button>
               </div>
            </div>
          </div>
        </aside>

        {/* Preview Panel - Ordered on Top for Mobile */}
        <section className="flex-1 flex flex-col relative bg-transparent min-h-[420px] sm:min-h-[500px] lg:min-h-0 order-1 lg:order-2">
          <div className="flex-1 relative flex items-center justify-center p-4 sm:p-12 min-h-0">
            {isProcessing && (
              <div className="absolute inset-0 z-20 flex items-center justify-center bg-white/60 backdrop-blur-sm">
                <LoadingScreen />
              </div>
            )}

            {activeResult && (
               <StampDisplay 
                imageUrl={activeResult.imageUrl} 
                originalName={activeResult.originalName} 
                onReset={handleGoBack}
                minimal
              />
            )}
          </div>

          {/* History Gallery Bar */}
          <div className="h-32 border-t border-stone-200/50 flex flex-col shrink-0 bg-white/80 backdrop-blur">
            <div className="px-4 sm:px-6 py-2 border-b border-stone-100 flex items-center justify-between">
               <span className="text-[9px] font-black uppercase tracking-widest text-stone-400 flex items-center gap-2">
                 <Layout size={10} /> Gallery
               </span>
               <span className="text-[9px] font-bold text-stone-300 uppercase">{history.length} Stamps</span>
            </div>
            <div className="flex-1 flex items-center gap-6 px-4 sm:px-6 overflow-x-auto scrollbar-hide py-4 snap-x snap-mandatory">
              {history.map((stamp) => (
                <button
                  key={stamp.id}
                  onClick={() => selectFromHistory(stamp)}
                  className={`
                    relative h-full aspect-[4/5] bg-white rounded-lg border shrink-0 transition-all overflow-hidden p-1.5 shadow-sm snap-start
                    ${activeResult?.id === stamp.id ? 'border-stone-900 scale-110 shadow-xl z-10' : 'border-stone-200 hover:border-stone-400'}
                  `}
                  style={{
                    backgroundImage: `linear-gradient(45deg, #fdfdfd 25%, transparent 25%), 
                                      linear-gradient(-45deg, #fdfdfd 25%, transparent 25%), 
                                      linear-gradient(45deg, transparent 75%, #fdfdfd 75%), 
                                      linear-gradient(-45deg, transparent 75%, #fdfdfd 75%)`,
                    backgroundSize: '8px 8px'
                  }}
                >
                  <img 
                    src={stamp.imageUrl} 
                    alt="Thumbnail" 
                    className="w-full h-full object-contain drop-shadow-sm"
                  />
                </button>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Workspace Footer */}
      <footer className="h-auto md:h-20 py-4 px-4 sm:px-12 border-t border-stone-200/50 flex flex-col sm:flex-row items-stretch sm:items-center justify-between bg-white/90 backdrop-blur shrink-0 fixed bottom-0 left-0 right-0 z-30 gap-3">
        <button 
          onClick={handleGoBack}
          className="flex items-center justify-center gap-2 px-6 py-3.5 border border-stone-200 text-stone-900 rounded-lg font-black uppercase tracking-[0.2em] text-[10px] shadow-sm hover:bg-stone-50 transition-all group shrink-0 active:scale-95"
        >
          <ChevronLeft size={14} className="group-hover:-translate-x-1 transition-transform text-stone-800" />
          Back
        </button>

        <div className="flex flex-row items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => activeResult && downloadImage(activeResult.imageUrl, activeResult.originalName)}
            disabled={!activeResult || isProcessing}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2.5 px-4 sm:px-8 py-3.5 bg-stone-900 text-white rounded-lg font-black uppercase tracking-[0.2em] text-[10px] shadow-lg hover:bg-stone-800 transition-all disabled:opacity-30 disabled:cursor-not-allowed group active:scale-95"
          >
            <FileImage size={14} className="group-hover:scale-110 transition-transform text-white shrink-0" />
            <span className="truncate">Export PNG</span>
          </button>

          <button
            onClick={() => activeResult && downloadSVG(activeResult.imageUrl, activeResult.originalName)}
            disabled={!activeResult || isProcessing}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2.5 px-4 sm:px-8 py-3.5 bg-white border border-stone-200 text-stone-900 rounded-lg font-black uppercase tracking-[0.2em] text-[10px] shadow-sm hover:bg-stone-50 transition-all disabled:opacity-30 disabled:cursor-not-allowed group active:scale-95"
          >
            <Code size={14} className="group-hover:scale-110 transition-transform text-stone-900 shrink-0" />
            <span className="truncate">Export SVG</span>
          </button>
        </div>
      </footer>
    </div>
  );
};

export default App;
