
import React from 'react';
import { PenTool } from 'lucide-react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center animate-pulse p-4 text-center">
      <div className="relative mb-6 sm:mb-8">
        <div className="w-16 h-16 sm:w-20 sm:h-20 border-4 border-stone-200 border-t-amber-500 rounded-full animate-spin"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <PenTool className="text-amber-500 w-6 h-6 sm:w-8 sm:h-8" />
        </div>
      </div>
      <h3 className="text-lg sm:text-xl font-official font-bold text-stone-800 mb-2">Engraving in Progress</h3>
      <p className="text-stone-500 text-xs sm:text-sm text-center max-w-[250px]">Gemini is applying vintage intaglio textures and serrated edge perforations...</p>
    </div>
  );
};

export default LoadingScreen;
